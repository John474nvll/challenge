window.addEventListener('load', function () {

    botonEncriptar();

    botonDesencriptar();

    botonCopiar();
})